from django.contrib import admin
from django.urls import path
from railway.views import *
from django.conf.urls.static import static
from django.conf import settings
from django import forms

class VotersData(forms.Form):
    first_name= forms.CharField(max_length=100)
    last_name= forms.CharField(max_length=100)
    age= forms.IntegerField()

    def clean_age(self):
        age= self.cleaned_data.get("Passenger Age")
        if age < 5:
            raise forms.ValidationError("You must be at least 5 years old to vote")
        return age

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',nav,name="nav"),
    path('about/',About,name="about"),
    path('login/',Login_customer,name="login_customer"),
    path('register_customer/',Register_customer,name="register_customer"),
    path('contact/',Contact,name="contact"),
    path('search_train/',Search_Train,name="search_train"),
    path('book_detail/(?P<coun>[0-9]+)/(?P<pid>[0-9]+)/(<str:route1>)',Book_detail,name="book_detail"),
    path('delete_passenger/(?P<pid>[0-9]+)/(?P<bid>[0-9]+)/(<str:route1>)',Delete_passenger,name="delete_passenger"),
    path('dashboard/',Dashboard,name="dashboard"),
    path('card_detail/(?P<total>[0-9]+)/(?P<coun>[0-9]+)/(<str:route1>)/(?P<pid>[0-9]+)',Card_Detail,name="card_detail"),
    path('log_out/',Logout,name="log_out"),
    path('my_booking/',my_booking,name="my_booking"),
    path('delte_my_booking/(?P<pid>[0-9]+)',delte_my_booking,name="delte_my_booking"),
    path('dashboard2/', admindashboard, name="admindashboard"),
    path('addtrain/', Add_train, name="add_train"),
    path('addroute/', add_route, name="add_route"),
    path('edittrain/?P<pid>[0-9]+)', edit, name="edittrain"),
    path('editroute/?P<pid>[0-9]+)', Edit_route, name="editroute"),
    path('delete/?P<pid>[0-9]+)', delete, name="delete"),
    path('delete_route/?P<pid>[0-9]+)', delete_route, name="delete_route"),
    path('viewtrain/', view_train, name="view_train"),
    path('availableroute/', displayroute, name="availableroute"),
    path('viewbookings/', viewbookings, name="viewbookings"),
    path('deletebooking/(?P<pid>[0-9]+)',deletebooking,name="deletebooking"),
    path('view_ticket/(?P<pid>[0-9]+)',view_ticket, name="view_ticket"),

]+static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
